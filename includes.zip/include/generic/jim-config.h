#ifndef _JIM_CONFIG_H
#define _JIM_CONFIG_H
#define HAVE_LONG_LONG 1
#define JIM_UTF8 1
#define JIM_VERSION 83
#define SIZEOF_INT 4
#endif
